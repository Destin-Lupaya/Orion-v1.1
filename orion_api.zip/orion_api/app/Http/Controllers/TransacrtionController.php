<?php

namespace App\Http\Controllers;

use App\Models\Account;
use App\Models\AccountActivity;
use App\Models\Transacrtion;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\PointsController;

class TransacrtionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return Transacrtion::all();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $data = (array) $request->all();

        $transTable = "transaction_" . $data['activity']['activity_id'];
        if (!isset($data['account']) && !isset($data['points'])) {
            $status = 403;
            $response = array("message" => "No payment method was supplied");
            return response()->json($response, $status);
        }
        // return $transTable;
        $trans =  DB::table($transTable)->insert($data['trans']);

        $activity = AccountActivity::find($data['activity']['id']);
        $activity->update($data['activity']);

        if (isset($data['account'])) {
            $account = Account::find($data['account']['id']);
            $account->update($data['account']);
        }
        $transaction = null;
        if (isset($data['points'])) {
            $transaction = 'Consommation';
            $used_points = $data['points']['point'];
        }
        $points = PointsController::calculatePoints($data['trans']['client_number'], $data['trans']['amount'], $data['activity']['activity_id'], $transaction, $used_points ?? null, $data['trans']['type_operation']);

        return ['trans' => $trans, 'activity' => $activity, 'account' => $account ?? null, 'points' => $points ?? null];
    }

    /**
     * Display the specified resource.
     *
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

        $id = json_decode($id, true);

        $transTable = "transaction_" . $id['activity_id'];
        // return Transacrtion::find($id);

        $trans =  DB::table($transTable)->get();

        return $trans;
    }

    /**
     * Display the specified resource.
     *
     * @param  string  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $activity_id = json_decode($id, true);
        $activity_id = $activity_id['activity_id'];

        $transTable = "transaction_" . $activity_id;

        $data =  DB::table($transTable)
            ->where('id', $request->id)
            ->update($request->all());

        return $data;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return Transacrtion::destroy($id);
    }

    /**
     * transaction for the specified resource (account) from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function transAccount($id)
    {
        return Transacrtion::where('account_id', '=', $id)
            ->get();
    }
}
